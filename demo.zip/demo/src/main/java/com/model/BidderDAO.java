package com.model;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public interface BidderDAO {
	public void register(Bidder bidder);
	public void login(Bidder bidder);
	public List<Match> showMatchDetails();
	public void selectTeam(Team team);
	public boolean changeTeam(Team team);
	public void bid(Bidder bidder);
	public void cancelBid(Bidder bidder);
	public List <Team> viewPointsTable();
	public List <LeaderBoard> viewLearderboard();
	public List<Bidder> getregisterdetails();
	
	public void getupdatedetails(Bidder bidder);
	
	
	public Bidder findBidder(int bidderId);
	public void save(Bidder bidder);
	public void delete(Bidder bidder);
	
	
}
