package com.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Bidder {
	@OneToMany
	private List<LeaderBoard> leaderboardobj;
	
	@Id
	@GeneratedValue
private int bidderId;
private String userName;
private String password;
private String name;
private String email;
private String phNo;
private int a;

/*
public Bidder(String userName, String password) {
	super();
	this.password = password;
	this.userName=userName;
}
public Bidder(String userName, String password, String email) {
	super();
	this.userName = userName;
	this.password = password;
	this.email = email;
	
} */
public Bidder( String userName, String password, String name, String email, String phNo,int a) {
	super();
	
	this.userName = userName;
	this.password = password;
	this.name = name;
	this.email = email;
	this.phNo = phNo;
	this.a=a;
}

@Override
public String toString() {
	return "Bidder [bidderId=" + bidderId + ", userName=" + userName + ", password=" + password + ", name=" + name
			+ ", email=" + email + ", phNo=" + phNo + ", a=" + a + "]";
}
public Bidder() {
	super();
	
}

public int getBidderId() {
	return bidderId;
}
public Bidder(String userName) {
	super();
	this.userName = userName;
}
public void setBidderId(int bidderId) {
	this.bidderId = bidderId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhNo() {
	return phNo;
}
public void setPhNo(String phNo) {
	this.phNo = phNo;
}
public int getA() {
	return a;
}
public void setA(int a) {
	this.a = a;
}




}
