package com.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Result 
{
	@Id
	@GeneratedValue
	 private int Id;
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public Result(String firstTeam, String secondTeam, String thirdTeam) {
		super();
		this.firstTeam = firstTeam;
		this.secondTeam = secondTeam;
		this.thirdTeam = thirdTeam;
	}
	private String firstTeam;
	private String secondTeam;
	private String thirdTeam;
	public String getFirstTeam() {
		return firstTeam;
	}
	public void setFirstTeam(String firstTeam) {
		this.firstTeam = firstTeam;
	}
	public String getSecondTeam() {
		return secondTeam;
	}
	public void setSecondTeam(String secondTeam) {
		this.secondTeam = secondTeam;
	}
	public String getThirdTeam() {
		return thirdTeam;
	}
	public void setThirdTeam(String thirdTeam) {
		this.thirdTeam = thirdTeam;
	}
	public Result() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Result [firstTeam=" + firstTeam + ", secondTeam=" + secondTeam + ", thirdTeam=" + thirdTeam + "]";
	}
	
	
	

}