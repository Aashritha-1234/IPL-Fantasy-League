package com.model;

import java.lang.annotation.Repeatable;
import java.util.List;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.stereotype.Component;


@Component
public interface TeamDAO {
	
	public Team save(Team team);
	public boolean updateTeam(Team team);
	
	
	public List<Team> getteam();
	public void delete(Team team);
	public  Team findTeam(int teamId);
	

	

}
