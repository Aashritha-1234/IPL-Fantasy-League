package com.model;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;


@Component
public interface AdminDAO {
	public void login(Admin admin);
	public void manageTournoment(Tournaments tournament);
	public void scheduleMatches(Match match);
	public void resheduleMatches(Match match);
	public void cancelMatch(Match match);
	public List<Bidder> viewBidders();
	public void manageTeams(Team team);
	public void updateTeamStatistics(Team team);
	public void commenceTournament(Tournaments tournament);
	
	public Admin save(Admin admin);
	
	public Admin findadmin(int password);
	public void delete(Admin admin);
}
