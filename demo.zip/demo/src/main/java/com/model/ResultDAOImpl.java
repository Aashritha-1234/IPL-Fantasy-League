package com.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class ResultDAOImpl implements ResultDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public Result save(Result result) {
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(result);
		session.flush();
		session.close();
		tx.commit();
		return result;
		
	}

	@Override
	public void update(Result result) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.update(result);
		session.flush();
		session.close();
		tx.commit();
	}

	@Override
	public List<Result> getupdateTeamStandings() {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		List<Result> resultist=session.createQuery("select r from Result r").list();
		session.close();
		tx.commit();
		return resultist;
		
	}

	@Override
	public Result find(int Id) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Result result=session.get(Result.class,Id);
		session.close();
		tx.commit();
		return result;
	}

	@Override
	public void delete(Result result) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.delete(result);
		session.flush();
		session.close();
		tx.commit();
		
	}

}
