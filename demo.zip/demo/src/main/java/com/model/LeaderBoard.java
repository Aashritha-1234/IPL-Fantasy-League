package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class LeaderBoard {
	@Id
	@GeneratedValue
	private int bidderId;
	private int bidsParticipated;
	private int bidsWon;
	private int bidLost;
	private double percentile;
	private int bidder_ranking;

	public LeaderBoard(int bidsParticipated, int bidsWon, int bidLost, double percentile, int bidder_ranking) {
		super();
		this.bidsParticipated = bidsParticipated;
		this.bidsWon = bidsWon;
		this.bidLost = bidLost;
		this.percentile = percentile;
		this.bidder_ranking = bidder_ranking;
	}
	public LeaderBoard() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "LeaderBoard [bidderId=" + bidderId + ", bidsParticipated=" + bidsParticipated + ", bidsWon=" + bidsWon
				+ ", bidLost=" + bidLost + ", percentile=" + percentile + ", bidder_ranking=" + bidder_ranking + "]";
	}
	public int getBidderId() {
		return bidderId;
	}
	public void setBidderId(int bidderId) {
		this.bidderId = bidderId;
	}
	public int getBidsParticipated() {
		return bidsParticipated;
	}
	public void setBidsParticipated(int bidsParticipated) {
		this.bidsParticipated = bidsParticipated;
	}
	public int getBidsWon() {
		return bidsWon;
	}
	public void setBidsWon(int bidsWon) {
		this.bidsWon = bidsWon;
	}
	public int getBidLost() {
		return bidLost;
	}
	public void setBidLost(int bidLost) {
		this.bidLost = bidLost;
	}
	public double getPercentile() {
		return percentile;
	}
	public void setPercentile(double percentile) {
		this.percentile = percentile;
	}
	public int getBidder_ranking() {
		return bidder_ranking;
	}
	public void setBidder_ranking(int bidder_ranking) {
		this.bidder_ranking = bidder_ranking;
	}
	
}
