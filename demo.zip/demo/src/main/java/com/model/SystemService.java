package com.model;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class SystemService {
	
	@Autowired
	SystemDAO SystemDaoImpl;
	
	@PersistenceContext
    private EntityManager entityManager;
	
	public void updateTeamStandings(Result result)
	   {
		entityManager.persist( result);
	   }
	public void updateLeaderboard(LeaderBoard leaderboard) {
		entityManager.persist(leaderboard);
	}
	public void updateBidderPoints(LeaderBoard leaderboard) {
	
	entityManager.persist(leaderboard);
	}
	public void updateMatchStat(Match match) {

	entityManager.persist(match);
	}
	public void declareResults(Match match) {
		entityManager.persist(match);
	}
	public void sendUpdatesToUser(LeaderBoard leaderboard) {
		entityManager.persist(leaderboard);
	}
	public void flushPointsTable(Team team) {
		SystemDaoImpl.flushPointsTable(team);
	}
	}

