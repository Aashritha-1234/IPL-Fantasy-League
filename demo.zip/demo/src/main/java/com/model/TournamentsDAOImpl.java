package com.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class TournamentsDAOImpl implements TournamentsDAO{


	@Autowired
	SessionFactory sessionFactory;
	@Override
	public Tournaments save(Tournaments tournament) 
	{
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(tournament);
		session.flush();
		session.close();
		tx.commit();
		return tournament;
	}

	@Override
	public List<Tournaments> gettournaments() 
	{
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		List<Tournaments> tlist=session.createQuery("select t from tournament t").list();
		session.close();
		tx.commit();
		
		return tlist;
	}

	@Override
	public List<Tournaments> settournaments() 
	{
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		List<Tournaments> tlist=session.createQuery("select t from tournament t").list();
		session.close();
		tx.commit();
		return tlist;
	}

	public Tournaments findTournaments(int tournamentId) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Tournaments tournaments=session.get(Tournaments.class, tournamentId);
		session.close();
		tx.commit();
		return tournaments;
	}

}
