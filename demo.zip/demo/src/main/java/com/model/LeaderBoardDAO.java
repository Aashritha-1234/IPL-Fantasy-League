package com.model;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public interface LeaderBoardDAO 
{
	public LeaderBoard save(LeaderBoard leaderBoard);
	
	public void update(LeaderBoard leaderBoard);

	public List<LeaderBoard> getLeaderBoard();

	public List<LeaderBoard> setLeaderBoard();

	public LeaderBoard find(int bidderId);

	public void delete(LeaderBoard lb);

}
