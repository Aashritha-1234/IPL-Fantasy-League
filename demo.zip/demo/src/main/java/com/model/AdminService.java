package com.model;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class AdminService {
	@Autowired
	AdminDAO adminDAOImpl;
	public void manageTournoment(Tournaments tournament) {
		 adminDAOImpl.manageTournoment(tournament);
	}
	public void scheduleMatches(Match match) {
		 adminDAOImpl.scheduleMatches(match);
	}
	public void resheduleMatches(Match match) {
		adminDAOImpl.resheduleMatches(match);
	}
	public void cancelMatch(Match match) {
		adminDAOImpl.cancelMatch(match);
	}
	public List<Bidder> viewBidders() {
		return adminDAOImpl.viewBidders();
	}
	public void manageTeams(Team team) {
		adminDAOImpl.manageTeams(team);
	}
	public void updateTeamStatistics(Team team) {
		adminDAOImpl.updateTeamStatistics(team);
	}
	public void commenceTournament(Tournaments tournament) {
		adminDAOImpl.commenceTournament(tournament);
	}
	public Admin save(Admin admin) {
		return adminDAOImpl.save(admin);
	}
	/*public Admin find(String userName) {
		return adminDAOImpl.find(userName);
		} */
	public Admin findadmin(int password) {
		return adminDAOImpl.findadmin(password);
	}
	public void login(Admin admin) {
		adminDAOImpl.save(admin);
	}
	public void delete(Admin admin) {
		// TODO Auto-generated method stub
		adminDAOImpl.delete(admin);
	}
}
