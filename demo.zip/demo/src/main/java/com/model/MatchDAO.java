package com.model;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public interface MatchDAO {
	
	public Match save(Match match);

	public List<Match> getmatch();
	public boolean updateMatch(Match match);
	public void cancelMatch(Match match);
	public List<Match> getUpdateMatchSta();
	public List<Match> setmatch();

	public Match find(int matchId);

	
	
	

}
