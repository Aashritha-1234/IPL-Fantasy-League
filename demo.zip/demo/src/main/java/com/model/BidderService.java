package com.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BidderService {
	
	
		@Autowired
		BidderDAO bidderDAOImpl;
		
		@PersistenceContext
	    private EntityManager entityManager;
		
		@Transactional
		   public void register(Bidder bidder)
		   {
			entityManager.persist(bidder);
		   }
		@Transactional
		   public void login(Bidder bidder)
		   {
			entityManager.persist(bidder);
		   }
		
		   public List<Match> showMatchDetails()
		   {
			    return bidderDAOImpl.showMatchDetails();
		   }
		@Transactional
		   public void selectTeam(Team team) 
		
		   {
			entityManager.persist(team);
		   }
		@Transactional
		   public boolean changeTeam(Team team) 
		   {
			   return  bidderDAOImpl.changeTeam(team);
		   }
		@Transactional
		public void bid(Bidder bidder) 
		   {
			   bidderDAOImpl.bid(bidder);
		   }
		@Transactional
		   public void cancelBid(Bidder bidder) 
		   {
			entityManager.remove(entityManager.contains(bidder) ? bidder : entityManager.merge(bidder));
		   }
		@Transactional
		   public List <Team> viewPointsTable()
		   {
			    return bidderDAOImpl.viewPointsTable();
		   }
		@Transactional
		   public List <LeaderBoard> viewLearderboard() 
		   {
			    return bidderDAOImpl.viewLearderboard();
		   }
		public List<Bidder> getregisterdetails() {
			return bidderDAOImpl.getregisterdetails();
			
		}
		public void update(Bidder bidder) {
			bidderDAOImpl.getupdatedetails(bidder);
			
		}
		
		public Bidder findBidder(int bidderId) 
		{
			return bidderDAOImpl.findBidder(bidderId);
		}
		public void save(Bidder bidder) {
			bidderDAOImpl.save(bidder);
		}
		/*
		public Bidder findBidder(String userName) {
			return bidderDAOImpl.findBidder(userName);
		} */
		public void delete(Bidder bidder) {
			bidderDAOImpl.delete(bidder);
		}
		

	}




