package com.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MatchDAOImpl implements MatchDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public Match save(Match match) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(match);
		session.flush();
		session.close();
		tx.commit();
		return match;
	}
	
	@Override
	public List<Match> getmatch() {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		List<Match> matchlist=session.createQuery("select m from Match m").list();
		session.close();
		tx.commit();
		return matchlist;
		
	}
	@Override
	public boolean updateMatch(Match match) {

		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.update(match);
		session.flush();
		session.close();
		tx.commit();
		return true;
	}
	@Override
	public void cancelMatch(Match match) {

		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.delete(match);
		session.flush();
		session.close();
		tx.commit();
		
	}
	
	@Override
	public List<Match> setmatch() {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		List<Match> matchlist=session.createQuery("select m from Match m").list();
		session.close();
		tx.commit();
		return matchlist;
		
	}
	public List<Match> getUpdateMatchSta() 
	{
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		List<Match> matchlist=session.createQuery("select m from Match m").list();
		session.close();
		tx.commit();
		return matchlist;
		
	}
	public Match find(int matchId) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Match match=session.get(Match.class,matchId);
		session.close();
		tx.commit();
		return match;
	}
	

}
