package com.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TeamDAOImpl implements TeamDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public Team save(Team team) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(team);
		session.flush();
		session.close();
		tx.commit();
		return team;
		
	} 

	@Override
	public List<Team> getteam() {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		List<Team> teamlist=session.createQuery("select t from Team t").list();
		session.close();
		tx.commit();
		return teamlist;
	}

	

	@Override
	public boolean updateTeam(Team team) {

		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.update(team);
		session.flush();
		session.close();
		tx.commit();
		return true;
	}

	@Override
	public void delete(Team team) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.delete(team);
		session.flush();
		session.close();
		tx.commit();
		
	}

	public Team findTeam(int teamId) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Team team=session.get(Team.class, teamId);
		session.close();
		tx.commit();
		return team;
	}

	

}
