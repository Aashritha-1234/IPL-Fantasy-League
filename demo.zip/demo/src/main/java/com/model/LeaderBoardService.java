package com.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LeaderBoardService {

	@Autowired
	LeaderBoardDAO leaderBoardDAOImpl;
	
	public LeaderBoard save(LeaderBoard leaderBoard)
	   {
		   return leaderBoardDAOImpl.save(leaderBoard);
	   }
	
  public List<LeaderBoard> getleaderBoard() 
  {
	  return leaderBoardDAOImpl.getLeaderBoard();
  }
  public void update(LeaderBoard leaderBoard) 
  {
	  leaderBoardDAOImpl.update(leaderBoard); 
  }
  public List<LeaderBoard> setmatch() 
  {
	  return leaderBoardDAOImpl.setLeaderBoard();
	  
  }
  public LeaderBoard find(int bidderId) {
	  return leaderBoardDAOImpl.find(bidderId);
  }

public void delete(LeaderBoard lb) {
	leaderBoardDAOImpl.delete(lb);
	
}
}
