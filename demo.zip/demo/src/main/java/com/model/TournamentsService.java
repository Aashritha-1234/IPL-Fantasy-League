package com.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class TournamentsService {
	
	@Autowired
	TournamentsDAO tournamentDAOImpl;
	
	public Tournaments save(Tournaments tournament)
	   {
		   return tournamentDAOImpl.save(tournament);
	   }
	
  public List<Tournaments> gettournaments() 
  {
	  return tournamentDAOImpl.gettournaments();
  }
  
  public List<Tournaments> settournaments() 
  {
	  return tournamentDAOImpl.settournaments();
  }
  public Tournaments findTournaments(int tournamentId) {
	  return tournamentDAOImpl.findTournaments(tournamentId);
  }

}
