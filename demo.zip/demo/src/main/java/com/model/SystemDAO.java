package com.model;

import org.springframework.stereotype.Component;

@Component
public interface SystemDAO {
	public void updateTeamStandings(Result result);
	public void updateLeaderboard(LeaderBoard leaderboard);
	public void updateBidderPoints(LeaderBoard leaderboard);
	public void updateMatchStat(Match match);
	public void declareResults(Match match);
	public void sendUpdatesToUser(LeaderBoard leaderboard);
	public void flushPointsTable(Team team);
	public void save(System system);
}
