package com.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.sql.Delete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BidderDAOImpl implements BidderDAO{
	
	@Autowired
	SessionFactory sessionFactory;
	


	@Override
	public void register(Bidder bidder) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(bidder);
		session.flush();
		session.close();
		tx.commit();
	}

	@Override
	public void login(Bidder bidder) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(bidder);
		session.flush();
		session.close();
		tx.commit();
	}

	@Override
	public List<Match> showMatchDetails() {
		Session session=sessionFactory.openSession();
		
		List<Match> matchlist=session.createQuery("select m from Match m").list();
		session.close();
		return matchlist;
		
	}
	public List<Bidder> getregisterdetails()  {
Session session=sessionFactory.openSession();
		
		List<Bidder> reg=session.createQuery("select b from Bidder b").list();
		session.close();
		return reg;
	}

	@Override
	public void selectTeam(Team team) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(team);
		session.flush();
		session.close();
		tx.commit();
	}

	@Override
	public boolean changeTeam(Team team) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.update(team);
		session.flush();
		session.close();
		tx.commit();
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void bid(Bidder bidder)  {
	
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(bidder);
		session.flush();
		session.close();
		tx.commit();
		
	}

	@Override
	public void cancelBid(Bidder bidder)  {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.delete(bidder);
		session.flush();
		session.close();
		tx.commit();
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Team> viewPointsTable() {
		Session session=sessionFactory.openSession();
		List<Team> pointstable =session.createQuery("select t from Team t").list();
		session.close();
		return pointstable;
	}

	@Override
	public List<LeaderBoard> viewLearderboard() {
		Session session=sessionFactory.openSession();
		List<LeaderBoard> leaderboard =session.createQuery("select l from LeaderBoard l").list();
		session.close();
		return leaderboard;
	}

	@Override
	public void getupdatedetails(Bidder bidder) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.update(bidder);
		session.flush();
		session.close();
		tx.commit();
	}

	

	@Override
	public Bidder findBidder(int bidderId) {
		// TODO Auto-generated method stub
		//return null;
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Bidder bidder=session.get(Bidder.class,bidderId);
		tx.commit();
		session.close();
		return bidder;
	}

	@Override
	public void save(Bidder bidder) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(bidder);
		session.flush();
		session.close();
		tx.commit();
	}
	/*
	public Bidder findBidder(String userName) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Bidder bidder=session.get(Bidder.class,userName);
		tx.commit();
		session.close();
		return bidder;
	} */
	public void delete(Bidder bidder) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.delete(bidder);
		tx.commit();
		session.close();
	}

	

	
	

	
}
