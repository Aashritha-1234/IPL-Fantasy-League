package com.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MatchService {
	
	@Autowired
	MatchDAO matchDAOImpl;
	
	@PersistenceContext
    private EntityManager em;
	
	public Match save(Match match)
	   {
		   return matchDAOImpl.save(match);
	   }
	
  public List<Match> getmatch() 
  {
	  return matchDAOImpl.getmatch();
  }
  
  public List<Match> setmatch() 
  {
	  return matchDAOImpl.setmatch();
  }

public boolean updateMatch(Match match) {
	return matchDAOImpl.updateMatch(match);
	
}
public List<Match> getUpdateMatchSta() 
{
	  return matchDAOImpl.getUpdateMatchSta();
}

@Transactional
public void cancelMatch(Match match) {
	em.remove(em.contains(match) ? match : em.merge(match));

}
public Match find(int matchId) {
	return matchDAOImpl.find(matchId);
}


	   
	  
}
