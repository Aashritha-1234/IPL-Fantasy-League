package com.model;
import java.lang.annotation.Repeatable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
public class Team 
{

	@OneToMany
	private List<Match> matchobj;
	@Id
	@GeneratedValue
	private int teamId;  
	private String tName;
	private int points;
	private int ranking;
	private String statistics;
	public int getTeamId() {
		return teamId;
	}
	public void setTeamId(int teamId) {
		this.teamId = teamId;
	}
	public String gettName() {
		return tName;
	}
	public void settName(String tName) {
		this.tName = tName;
	}
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
	public int getRanking() {
		return ranking;
	}
	public void setRanking(int ranking) {
		this.ranking = ranking;
	}
	public String getStatistics() {
		return statistics;
	}
	public void setStatistics(String statistics) {
		this.statistics = statistics;
	}
	public Team(String tName,String statistics) {
		super();
		this.tName = tName;
		this.statistics = statistics;
	}
	
	public Team(String tName, int points, int ranking, String statistics) {
		super();
		this.tName = tName;
		this.points = points;
		this.ranking = ranking;
		this.statistics = statistics;
	}
	public Team() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Team [teamId=" + teamId + ", tName=" + tName + ", points=" + points + ", ranking=" + ranking
				+ ", statistics=" + statistics + "]";
	}
	
}