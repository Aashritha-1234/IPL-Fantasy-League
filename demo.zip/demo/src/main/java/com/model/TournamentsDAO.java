package com.model;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public interface TournamentsDAO {
	
	public Tournaments save(Tournaments tournament);

	public List<Tournaments> gettournaments();

	public List<Tournaments> settournaments();
	public Tournaments findTournaments(int tournamentId);

	
	
	

}
