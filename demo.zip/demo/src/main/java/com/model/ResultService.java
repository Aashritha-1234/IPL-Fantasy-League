package com.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ResultService {
	
	@Autowired
	ResultDAO resultDAOImpl;
	
	public Result save(Result result)
	   {
		   return resultDAOImpl.save(result);
	   }

	public void update(Result result) {
		// TODO Auto-generated method stub
		 resultDAOImpl.update(result);
	}

	public List<Result> getupdateTeamStandings() {
		// TODO Auto-generated method stub
		return resultDAOImpl.getupdateTeamStandings();
	}
	public Result find(int Id) {
		return resultDAOImpl.find(Id);
	}

	public void delete(Result result) {
		resultDAOImpl.delete(result);
		
	}
}
