package com.model;

import java.util.List;

import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;




public class System {
	private int systemId;
	@OneToMany
	private List<Result> resultobj;
	@OneToMany
	private List<Bidder> bidderobj;
	@OneToMany
	private List<Team> teamobj;
	@OneToOne
	private Admin admin;
	
	public System(int systemId) {
		
		this.systemId = systemId;
	}

	public System() {
		super();
	}

	public int getSystemId() {
		return systemId;
	}
	public void setSystemId(int systemId) {
		this.systemId = systemId;
	}

	
} 
