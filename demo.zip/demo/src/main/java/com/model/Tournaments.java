package com.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Tournaments 
{
	@Id
	@GeneratedValue
	private int tournamentId;
	public int numberOfTeams;
	public Date duration;
	public int getTournamentId() {
		return tournamentId;
	}
	
	

	public Tournaments(int numberOfTeams, Date duration) {
		super();
		this.numberOfTeams = numberOfTeams;
		this.duration = duration;
	}



	public void setTournamentId(int tournamentId) {
		this.tournamentId = tournamentId;
	}
	public int getNumberOfTeams() {
		return numberOfTeams;
	}
	public void setNumberOfTeams(int numberOfTeams) {
		this.numberOfTeams = numberOfTeams;
	}
	public Date getDuration() {
		return duration;
	}
	public void setDuration(Date duration) {
		this.duration = duration;
	}
	public Tournaments() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Tournaments [tournamentId=" + tournamentId + ", numberOfTeams=" + numberOfTeams + ", duration="
				+ duration + "]";
	}

	
	
	

}