package com.model;

import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class AdminDAOImpl implements AdminDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public void manageTournoment(Tournaments tournament) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(tournament);
		session.flush();
		tx.commit();
		session.close();
	}

	@Override
	public void scheduleMatches(Match match) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(match);
		session.flush();
		tx.commit();
		session.close();
	}

	@Override
	public void resheduleMatches(Match match) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.update(match);
		session.flush();
		tx.commit();
		session.close();
	}
public void cancelMatch(Match match) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.delete(match);
		session.flush();
		tx.commit();
		session.close();
	}
	

	@Override
	public List<Bidder> viewBidders() 
	{
	Session session=sessionFactory.openSession();
	Transaction tx=session.beginTransaction();
	List<Bidder> bidderlist=session.createQuery("select b from Bidder b").list();
	tx.commit();
	return bidderlist;
	}

	@Override
	public void manageTeams(Team team) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(team);
		session.flush();
		tx.commit();
		session.close();
		
	}

	@Override
	public void updateTeamStatistics(Team team) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.update(team);
		session.flush();
		tx.commit();
		session.close();
	}

	@Override
	public void commenceTournament(Tournaments tournament) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(tournament);
		session.flush();
		tx.commit();
		session.close();
	}
	public Admin find(int adminId) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Admin admin=session.get(Admin.class,adminId);
		session.close();
tx.commit();
		return admin;
	}

	@Override
	public Admin save(Admin admin) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(admin);
		session.close();
tx.commit();// TODO Auto-generated method stub
		return null;
	}
	
	
	public Admin findadmin(int password) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Admin admin=session.get(Admin.class,password);
		tx.commit();
		session.close();
		return admin;
	}

	@Override
	public void login(Admin admin) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(admin);
		session.flush();
		tx.commit();
		session.close();
		
	}
	
	public void delete(Admin admin) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.delete(admin);
		session.flush();
		tx.commit();
		session.close();
	}
	

}
