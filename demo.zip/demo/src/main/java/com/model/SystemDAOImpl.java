package com.model;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SystemDAOImpl implements SystemDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public void updateTeamStandings(Result result) {
		Session session=sessionFactory.openSession();
		session.save(result);
		session.flush();
		session.close();
		
	}

	@Override
	public void updateLeaderboard(LeaderBoard leaderboard) {
		Session session=sessionFactory.openSession();
		session.update(leaderboard);
		session.flush();
		session.close();
	}

	@Override
	public void updateBidderPoints(LeaderBoard leaderboard) {
		
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		session.update(leaderboard);
		session.flush();
		session.close();
	}

	@Override
	public void updateMatchStat(Match match) {
		Session session=sessionFactory.openSession();
		session.update(match);
		session.flush();
		session.close();
		
	}

	@Override
	public void declareResults(Match match) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		session.save(match);
		session.flush();
		session.close();
		
	}

	@Override
	public void sendUpdatesToUser(LeaderBoard leaderboard) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		session.update(leaderboard);
		session.flush();
		session.close();
		
	}

	@Override
	public void flushPointsTable(Team team) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		session.delete(team);
		session.flush();
		session.close();
		
	}

	@Override
	public void save(System system) {
		// TODO Auto-generated method stub
		
	}

}
