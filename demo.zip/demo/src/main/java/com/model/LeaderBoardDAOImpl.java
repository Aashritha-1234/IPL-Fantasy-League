package com.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LeaderBoardDAOImpl implements LeaderBoardDAO
{
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public LeaderBoard save(LeaderBoard leaderBoard) 
	{
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(leaderBoard);
		session.flush();
		session.close();
		tx.commit();
		// TODO Auto-generated method stub
		return leaderBoard;
	}

	@Override
	public List<LeaderBoard> getLeaderBoard() 
	{
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		List<LeaderBoard> lbList=session.createQuery("select l from LeaderBoard l").list();
		tx.commit();
		session.close();
		// TODO Auto-generated method stub
		return lbList;
	}

	@Override
	public List<LeaderBoard> setLeaderBoard()
	{
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		List<LeaderBoard> lbList=session.createQuery("select l from LeaderBoard l").list();
		tx.commit();
		session.close();
		// TODO Auto-generated method stub
		return lbList;
		
		
	}

	@Override
	public void update(LeaderBoard leaderBoard) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.update(leaderBoard);
		session.flush();
		session.close();
		tx.commit();
		
	}
	public LeaderBoard find(int bidderId) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		LeaderBoard leaderboard=session.get(LeaderBoard.class,bidderId);
		session.close();
		tx.commit();
		return leaderboard ;
	}

	@Override
	public void delete(LeaderBoard lb) {
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.delete(lb);
		session.flush();
		session.close();
		tx.commit();
		
	}

}
