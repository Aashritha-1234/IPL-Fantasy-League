package com.model;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public interface ResultDAO {
	public Result save(Result result);

	public void update(Result result);

	public List<Result> getupdateTeamStandings();

	public Result find(int id);
	
	public void delete(Result result);
}