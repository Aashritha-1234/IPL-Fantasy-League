package com.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class TeamService {
	
	@Autowired

	TeamDAO teamDAOImpl;
	
	@PersistenceContext
    private EntityManager em;
	
	public Team save(Team team)
	   {
		   return teamDAOImpl.save(team);
	   }
	
public List<Team> getteam() 
{
	  return teamDAOImpl.getteam();
}


 public boolean updateTeam(Team team) {
return teamDAOImpl.updateTeam(team);   
}

 @Transactional
public void delete(Team team) {
	// TODO Auto-generated method stub
	em.remove(em.contains(team) ? team : em.merge(team));
}
 public  Team findTeam(int teamId) {

     return teamDAOImpl.findTeam(teamId);
 }
}
