package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Bidder;
import com.model.BidderService;
import com.model.LeaderBoard;
import com.model.LeaderBoardService;
import com.model.Match;
import com.model.MatchService;
import com.model.Result;
import com.model.ResultService;
import com.model.Team;
import com.model.TeamService;

import io.swagger.annotations.ApiOperation;

@RestController
public class SystemController{
	
	@Autowired(required=true)
	ResultService service;
	
	@Autowired(required=true)
	LeaderBoardService service1;
	
	@Autowired(required=true)
	BidderService service2;
	
	@Autowired(required=true)
	MatchService service3;
	
	@Autowired(required=true)
	TeamService service4;
	
	@PostMapping("/saveTeamStandings")
	 @ApiOperation(value = "Update a team", httpMethod = "POST")
	public ResponseEntity<?> saveTeamStandings(@RequestBody Result result)
	{
		service.save(result);
	   return ResponseEntity.ok("Saved");
	}

	@PostMapping("/updateTeamStandings")
	 @ApiOperation(value = "Update a team", httpMethod = "POST")
	public ResponseEntity<?> updateTeamStandings(@RequestBody Result result)
	{
		service.update(result);
	   return ResponseEntity.ok("Updation Successfull");
	}
	@GetMapping("/getupdateteam")
	@ResponseBody public ResponseEntity<?> getresult(){
		List<Result> result=service.getupdateTeamStandings();
		return new ResponseEntity<>(result,HttpStatus.OK);
		
	}
	
	@PostMapping("/updateLeaderBoard")
	 @ApiOperation(value = "update Leader Board", httpMethod = "POST")
	public ResponseEntity<?> updateLeaderboard(@RequestBody LeaderBoard leaderboard)
	{
		service1.update(leaderboard);
	   return ResponseEntity.ok("Updation Successfull");
	}
	
	@GetMapping("/getupdateLeaderBoard")
	
	@ResponseBody public ResponseEntity<?> getleaderboard(){
		List<LeaderBoard> leaderboard=service1.getleaderBoard();
		return new ResponseEntity<>(leaderboard,HttpStatus.OK);
		
	}
	@PostMapping("/updateBidderPoints")
	 @ApiOperation(value = "update a Bidder", httpMethod = "POST")
	public ResponseEntity<?>updateBidderPoints(@RequestBody LeaderBoard leaderboard)
	{
		service1.update(leaderboard);
	   return ResponseEntity.ok("Updation Successfull");
	}
	
	@GetMapping("/getupdateBidderPoints")
	
	@ResponseBody public ResponseEntity<?> getbidder(){
		List<LeaderBoard> lblist =service1.getleaderBoard();
		return new ResponseEntity<>(lblist,HttpStatus.OK);
		
	}
	@PostMapping("/updateMatchStat")
	 @ApiOperation(value = "update match stat", httpMethod = "POST")
	public ResponseEntity<?> updateMatchStat(@RequestBody Match match)
	{
		service3.updateMatch(match);
	   return ResponseEntity.ok("Updation Successfull");
	}
	
	@GetMapping("/getupdateMatchStat")
	
	@ResponseBody public ResponseEntity<?> getmatch(){
		List<Match> match=service3.getUpdateMatchSta();
		return new ResponseEntity<>(match,HttpStatus.OK);
		
	}
	@PostMapping("/declareResults")
	 @ApiOperation(value = "Declaring results", httpMethod = "POST")
	public ResponseEntity<?> declareResults(@RequestBody Match match)
	{
		service3.save(match);
	   return ResponseEntity.ok("Declaration Successfull");
	}
	@GetMapping("/declareResults")
	@ResponseBody public ResponseEntity<?> getresult1(){
		List<Match> result=service3.getmatch();
		return new ResponseEntity<>(result,HttpStatus.OK);
		
	}
	@PostMapping("/updatestoUser")
	 @ApiOperation(value = "updates to user", httpMethod = "POST")
	public ResponseEntity<?>updateToUser(@RequestBody LeaderBoard leaderboard)
	{
		service1.update(leaderboard);
	   return ResponseEntity.ok("Updation Successfull");
	}
	
	@GetMapping("/getupdatestouser")
	
	@ResponseBody public ResponseEntity<?> getupdatedbidderpoints(){
		List<LeaderBoard> lblist =service1.getleaderBoard();
		return new ResponseEntity<>(lblist,HttpStatus.OK);
		
	}
	
	@PostMapping("/flushpointstable")
	@ApiOperation(value = "Clear the teamtable", httpMethod = "POST")
	public ResponseEntity<?> flushpointstable(@RequestBody Team team)
	{
		service4.delete(team);
  return ResponseEntity.ok("Points Table flushed");
	}
	
}