package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Admin;
import com.model.AdminService;
import com.model.Bidder;
import com.model.BidderService;
import com.model.Match;
import com.model.MatchService;
import com.model.Team;
import com.model.TeamService;
import com.model.Tournaments;
import com.model.TournamentsService;

import io.swagger.annotations.ApiOperation;


@RestController
public class AdminController {
	
	@Autowired(required=true)
	AdminService service;
	
	@Autowired(required=true)
	MatchService service1;
	
	@Autowired(required=true)
	TournamentsService service2;
	
	@Autowired(required=true)
	TeamService service3;
	
	@PostMapping("/loginadmin")
	 @ApiOperation(value = "login a Admin", httpMethod = "POST")
	public ResponseEntity<?> login(@RequestBody Admin admin) {
		service.login(admin);
 return new ResponseEntity<>("Successful log in!", HttpStatus.OK);
	}
	
	@PostMapping("/postmanagetournament")
	@ApiOperation(value = "Schedule Tournament", httpMethod = "POST")



		public ResponseEntity<?> postmanagetournament(@RequestBody Tournaments tournament)
		{
			service2.save(tournament);
			return ResponseEntity.ok(tournament);
		}
	
	


@PostMapping("/schedulematch")
@ApiOperation(value = "Schedule Match", httpMethod = "POST")



	public ResponseEntity<?> postschedulematch(@RequestBody Match match)
	{
		service1.save(match);
		return ResponseEntity.ok(match);
	}
@GetMapping("/getschedulematchdetails")
@ResponseBody public ResponseEntity<?> getscheduledetails(){
	List<Match> matchlist=service1.getmatch();
	return new ResponseEntity<>(matchlist,HttpStatus.OK);
	
}

@PostMapping("/reschedulematch")
@ApiOperation(value = "Reschedule a match", httpMethod = "POST")
public ResponseEntity<?> changeTeam(@RequestBody Match match)
{
	service1.updateMatch(match);
  return ResponseEntity.ok("Change Successfull");
}
@GetMapping("/getrescheduledMatch")

@ResponseBody public ResponseEntity<?> getupdateteam(){
	List<Match> match=service1.getmatch();
	return new ResponseEntity<>(match,HttpStatus.OK);
	
}
@PostMapping("/cancelMatch")
@ApiOperation(value = "Delete a match", httpMethod = "POST")
public ResponseEntity<?> cancelMatch(@RequestBody Match match)
{
	service1.cancelMatch(match);
  return ResponseEntity.ok("Match got cancelled");
}

@GetMapping("/viewBidders")

@ResponseBody public ResponseEntity<?> getviewBidders(){
	List<Bidder> bidder=service.viewBidders();
	return new ResponseEntity<>(bidder,HttpStatus.OK);
	
}

@PostMapping("/postmanageteams")
@ApiOperation(value = "Manage Team", httpMethod = "POST")



	public ResponseEntity<?> postmanageteams(@RequestBody Team team)
	{
		service3.save(team);
		return ResponseEntity.ok(team);
	}


@GetMapping("/getmanageteams")

@ResponseBody public ResponseEntity<?> getmanagedteams(){
List<Team> tlist=service3.getteam();
return new ResponseEntity<>(tlist,HttpStatus.OK);
	
	
}

@PostMapping("/updateStatistics")
@ApiOperation(value = "Updation of teamStatistics", httpMethod = "POST")
public ResponseEntity<?> updateStatistics(@RequestBody Team team)
{
	service3.updateTeam(team);
  return ResponseEntity.ok("Updated team statistics");
}
@GetMapping("/getupdatedStatistics")

@ResponseBody public ResponseEntity<?> getupdatedStatistics(){
	List<Team> team=service3.getteam();
	return new ResponseEntity<>(team,HttpStatus.OK);
	
}

@PostMapping("/postcommencetournament")
@ApiOperation(value = "Start a Tournament", httpMethod = "POST")



	public ResponseEntity<?> postcommencetournament(@RequestBody Tournaments tournament)
	{
		service2.save(tournament);
		return ResponseEntity.ok(tournament);
	}



	
	
}



