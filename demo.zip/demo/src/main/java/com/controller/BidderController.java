package com.controller;

import com.model.Bidder;
import com.model.BidderService;
import com.model.LeaderBoard;
import com.model.LeaderBoardService;
import com.model.Match;
import com.model.MatchService;
import com.model.Team;
import com.model.TeamService;

import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import javax.transaction.Transactional;

@RestController
public class BidderController{
	
	@Autowired(required=true)
	BidderService service;
	
	@Autowired(required=true)
	MatchService service1;
	
	@Autowired(required=true)
	TeamService service2;
	
	@Autowired(required=true)
	LeaderBoardService service3;
	
	
	@PostMapping("/register")
	 @ApiOperation(value = "Save a Bidder", httpMethod = "POST")
	public ResponseEntity<?> postregister(@RequestBody Bidder bidder)
	{
		service.register(bidder);
	   return ResponseEntity.ok("Registration Successfull");
	}
	
	@GetMapping("/getregister")
	
	@ResponseBody public ResponseEntity<?> getregister(){
		List<Bidder> reg=service.getregisterdetails();
		return new ResponseEntity<>(reg,HttpStatus.OK);
		
	}
	
	
   
	@PostMapping("/login")
	 @ApiOperation(value = "login a Bidder", httpMethod = "POST")
	public ResponseEntity<?> login(@RequestBody Bidder bidder) {
		service.login(bidder);
    	if (bidder.getUserName() != null && bidder.getPassword() != null) {
            return new ResponseEntity<>("Successful log in!", HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>("Invalid Username and Password", HttpStatus.NOT_FOUND );
        }
    }
	
	@PostMapping("/showMatchDetails")
	  @ApiOperation(value = "Match Details", httpMethod = "POST")

	
	
		public ResponseEntity<?> postMatchDetails(@RequestBody Match match)
		{
			service1.save(match);
			return ResponseEntity.ok(match);
		}
	@GetMapping("/getmatchdetails")
	@ResponseBody public ResponseEntity<?> getMatchDetails(){
		List<Match> matchlist=service1.getmatch();
		return new ResponseEntity<>(matchlist,HttpStatus.OK);
		
	}
	
	@PostMapping("/viewPointsTable")
	  @ApiOperation(value = "Points Table Details", httpMethod = "POST")

	public ResponseEntity<?> postpointsTable(@RequestBody Team team)
	{
		service2.save(team);
		return ResponseEntity.ok(team);
	}
	@GetMapping("/getpointstable")
	@ResponseBody public ResponseEntity<?> getpointsTable(){
		List<Team> teamlist=service2.getteam();
		return new ResponseEntity<>(teamlist,HttpStatus.OK);
		
	}
	
	
	
	@PostMapping("/viewLeaderboard")
	  @ApiOperation(value = "Leader Board", httpMethod = "POST")
public ResponseEntity<?> viewLeaderboard(@RequestBody LeaderBoard leaderBoard) {
		service3.save(leaderBoard);
		return ResponseEntity.ok(leaderBoard);
	}
	@GetMapping("/getLeaderboard")
	@ResponseBody public ResponseEntity<?> getLeaderboard(){
		List<LeaderBoard> lblist=service3.getleaderBoard();
		return new ResponseEntity<>(lblist,HttpStatus.OK);
		
	}
		
	
	
	@PostMapping("/selectTeam")
	 @ApiOperation(value = "Select a team", httpMethod = "POST")
	public ResponseEntity<?> selectTeam(@RequestBody Team team)
	{
		service2.save(team);
	   return ResponseEntity.ok("Selection Successfull");
	}
	@GetMapping("/getselectteam")
	@ResponseBody public ResponseEntity<?> getteam(){
		List<Team> team=service2.getteam();
		return new ResponseEntity<>(team,HttpStatus.OK);
		
	}
	
	@PostMapping("/changeTeam")
	 @ApiOperation(value = "change a team", httpMethod = "POST")
	public ResponseEntity<?> changeTeam(@RequestBody Team team)
	{
		service2.updateTeam(team);
	   return ResponseEntity.ok("Change Successfull");
	}
@GetMapping("/getteam")
	
	@ResponseBody public ResponseEntity<?> getupdateteam(){
		List<Team> team=service2.getteam();
		return new ResponseEntity<>(team,HttpStatus.OK);
		
	}
	
	@PostMapping("/BidAmount")
	 @ApiOperation(value = "Bid", httpMethod = "POST")
	public ResponseEntity<?> bid(@RequestBody Bidder bidder)
	{
		service.bid(bidder);
	   return ResponseEntity.ok("Amount bid is:" +bidder);
	}
	
	@PostMapping("/cancelBid")
	 @ApiOperation(value = "cancelBid", httpMethod = "POST")
	public ResponseEntity<?> cancelBid(@RequestBody Bidder bidder)
	{
		service.cancelBid(bidder);
	   return ResponseEntity.ok("Bid Cancelled");
	}
	
	
		
	}

    


