/* package com.exceptions;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
@ControllerAdvice

public class Globalexception  {
	
	@ExceptionHandler(value=AdminNotFoundException.class)
	public ResponseEntity<Object> exception(AdminNotFoundException exception)
	{
	return new ResponseEntity<>("Admin Not Found",HttpStatus.NOT_FOUND);
	}
	}

*/
