 /* package com.exceptions;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.model.Admin;


@RestController
public class AdminNotFoundException  {

   private static Map<String, String> adminRepo = new HashMap<>();
   static {
	   
      Admin honey = new Admin();
     // honey.setAdminId(1);
      honey.setUserName("Honey");
      honey.setPassword("Honey123");
      adminRepo.put("Honey", "Honey123");
      
      Admin almond = new Admin();
      //honey.setAdminId(2);
      almond.setUserName("Almond");
      almond.setPassword("Almond123");
      adminRepo.put("Almond", "Almond123");
   }
   
   @RequestMapping(value = "/Admins/{id}", method = RequestMethod.PUT)
   public ResponseEntity<Object> updateAdmin1(@RequestBody Admin admin) { 
      throw new AdminNotFoundException();
      //adminRepo.remove(id);
      //admin.setAdminId(id);
      //adminRepo.put(userName, admin);
      return new ResponseEntity<>("Admin is updated successfully", HttpStatus.OK);
   }
}


@Autowired
//AdminDAOImpl adminService;
     
       @PostMapping("/update")
	public ResponseEntity<Admin> updateAdmin(@RequestBody Admin admin) {
		adminService.updateAdmin(admin);
		return new ResponseEntity<Admin>(admin, HttpStatus.OK);
	}
	@GetMapping("/get/{id}")
	public ResponseEntity<?> getAdmin(@PathVariable("id") long id){
          
		Admin admin=adminService.findAdmin(id);  
                if(admin==null)
               {
                  throw new AdminNotfoundException();
               }
               else
              {
               return new ResponseEntity<>(adminList,HttpStatus.OK);
              }
              }
	}  */