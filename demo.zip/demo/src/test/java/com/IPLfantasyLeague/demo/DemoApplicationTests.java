package com.IPLfantasyLeague.demo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Date;
import java.util.List;

import org.assertj.core.api.AbstractCharSequenceAssert;
import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.google.common.net.MediaType;
import com.model.Admin;
import com.model.AdminDAO;
import com.model.AdminService;
import com.model.Bidder;
import com.model.BidderDAO;
import com.model.BidderDAOImpl;
import com.model.BidderService;
import com.model.LeaderBoard;
import com.model.LeaderBoardDAO;
import com.model.LeaderBoardService;
import com.model.Match;
import com.model.MatchDAO;
import com.model.MatchService;
import com.model.Result;
import com.model.ResultDAO;
import com.model.ResultService;
import com.model.System;
import com.model.SystemDAO;
import com.model.Team;
import com.model.TeamDAO;
import com.model.TeamDAOImpl;
import com.model.TeamService;
import com.model.Tournaments;
import com.model.TournamentsDAO;
import com.model.TournamentsDAOImpl;
import com.model.TournamentsService;
import com.model.TournamentsDAOImpl;

@EnableTransactionManagement
@SpringBootTest
public class DemoApplicationTests {

private Date date;
	
	@Autowired
	BidderService bidderDAOImpl;
	
	@Autowired
	AdminService adminDAOImpl;
	
	@Autowired
	MatchService matchDAOImpl;
	
	@Autowired
	LeaderBoardService leaderboardDAOImpl;
	
	@Autowired
	ResultService resultDAOImpl;
	
	@Autowired
	TournamentsService tournamentDAOImpl;
	
	@Autowired
	TeamService teamDAOImpl;

@Test
void saveTest1() {
Bidder bidder=new Bidder("Harry","Thames", "HedrickThames", "hedrick@gmail.com","123456789",500);
bidderDAOImpl.save(bidder);
Bidder product1 = bidderDAOImpl.findBidder(bidder.getBidderId());
assertThat("Harry").isEqualTo(product1.getUserName());
assertThat("Thames").isEqualTo(product1.getPassword());
assertThat("HedrickThames").isEqualTo(product1.getName());
assertThat("hedrick@gmail.com").isEqualTo(product1.getEmail());
assertThat("123456789").isEqualTo(product1.getPhNo());
assertThat(500).isEqualTo(product1.getA());
}

@Test
void findTest1() 
{
Bidder bidder=new Bidder("Harry","Thames", "HedrickThames", "hedrick@gmail.com","123456789",500);	
bidderDAOImpl.save(bidder);
Bidder product1 = bidderDAOImpl.findBidder(bidder.getBidderId());
assertThat(product1.getBidderId()).isGreaterThan(0);
assertThat(product1.getUserName()).hasSizeGreaterThan(0);
assertThat(product1.getName()).hasSizeGreaterThan(0);
assertThat(product1.getPassword()).hasSizeGreaterThan(0);
assertThat(product1.getEmail()).hasSizeGreaterThan(0);
assertThat(product1.getPhNo()).hasSizeGreaterThan(0);
assertThat(product1.getA()).isGreaterThan(0);
}

@Test
void updateTest() {
Bidder bidder=new Bidder("Harry","Thames", "HedrickThames", "hedrick@gmail.com","123456789",500);	
bidder.setUserName("Akhil");
bidder.setPassword("Kohli");
bidder.setName("AkhilKohli");
bidder.setEmail("sunny@gmail.com");
bidder.setPhNo("9632514783");
bidder.setA(50);

bidderDAOImpl.save(bidder);
Bidder product1 = bidderDAOImpl.findBidder(bidder.getBidderId());
assertThat(product1.getUserName()).isEqualTo("Akhil");
assertThat(product1.getPassword()).isEqualTo("Kohli");
assertThat(product1.getName()).isEqualTo("AkhilKohli");
assertThat(product1.getEmail()).isEqualTo("sunny@gmail.com");
assertThat(product1.getPhNo()).isEqualTo("9632514783");
assertThat(product1.getA()).isEqualTo(50);
}

@Test
void deleteTest1() {
Bidder bidder=new Bidder("Akhil","Kohli", "AkhilKohli", "sunny@gmail.com","9632514783",50);	
bidderDAOImpl.delete(bidder);
Bidder product1 = bidderDAOImpl.findBidder(bidder.getBidderId());
assertThat(product1).isNull();
}

@Test
void saveTest2() {
Admin admin=new Admin("Harry","Thames");
adminDAOImpl.save(admin);
Admin product2 = adminDAOImpl.findadmin(admin.getAdminId());
assertThat("Harry").isEqualTo(product2.getUserName());
assertThat("Thames").isEqualTo(product2.getPassword());
}

@Test
void findTest2() 
{
Admin admin=new Admin("Harry","Thames");
adminDAOImpl.save(admin);
Admin product2 = adminDAOImpl.findadmin(admin.getAdminId());
assertThat(product2.getUserName()).hasSizeGreaterThan(0);
assertThat(product2.getPassword()).hasSizeGreaterThan(0);
}

@Test
void updateTest2() {
Admin admin=new Admin("Harry","Thames");
admin.setUserName("Akhil");
admin.setPassword("Kohli");
adminDAOImpl.save(admin);
Admin product1 = adminDAOImpl.findadmin(admin.getAdminId());
assertThat(product1.getUserName()).isEqualTo("Akhil");
assertThat(product1.getPassword()).isEqualTo("Kohli");
}


@Test
void deleteTest2() {
Admin admin=new Admin("Akhil","Kohli");
adminDAOImpl.delete(admin);
Admin product1 = adminDAOImpl.findadmin(admin.getAdminId());
assertThat(product1).isNull();
}

@Test
void saveMatch() {
Match match=new Match("RCB","CSK",date,"Sharjah","CSK");	
 matchDAOImpl.save(match);
Match product1 = matchDAOImpl.find(match.getMatchId());
assertThat("RCB").isEqualTo(product1.getTeamOne());
assertThat("CSK").isEqualTo(product1.getTeamTwo());
assertThat(date).isEqualTo(product1.getDate());
assertThat("Sharjah").isEqualTo(product1.getStadium());
assertThat("CSK").isEqualTo(product1.getWinner());
}

@Test
void find() 
{
Match match=new Match("RCB","CSK",date,"Sharjah","CSK");	
matchDAOImpl.save(match);
Match product1 = matchDAOImpl.find(match.getMatchId());
assertThat(product1.getTeamOne()).hasSizeGreaterThan(0);
assertThat(product1.getTeamTwo()).hasSizeGreaterThan(0);

assertThat(product1.getStadium()).hasSizeGreaterThan(0);
assertThat(product1.getWinner()).hasSizeGreaterThan(0);
}

@Test
void updateMatch() {
Match match=new Match("RCB","CSK",date,"Sharjah","CSK");
match.setTeamOne("MI");
match.setTeamTwo("DC");
match.setStadium("Abudhabi");
match.setWinner("DC");
matchDAOImpl.find(match.getMatchId());
matchDAOImpl.save(match);
Match product1 = matchDAOImpl.find(match.getMatchId());
assertThat(product1.getTeamOne()).isEqualTo("MI");
assertThat(product1.getTeamTwo()).isEqualTo("DC");
assertThat(product1.getStadium()).isEqualTo("Abudhabi");
assertThat(product1.getWinner()).isEqualTo("DC");
}

@Test
void saveLeaderBoard() {
LeaderBoard lb=new LeaderBoard(10,8, 2, 80.9,3);
 leaderboardDAOImpl.save(lb);
LeaderBoard product1 = leaderboardDAOImpl.find(lb.getBidderId());
assertThat(10).isEqualTo(product1.getBidsParticipated());
assertThat(8).isEqualTo(product1.getBidsWon());
assertThat(2).isEqualTo(product1.getBidLost());
assertThat(80.9).isEqualTo(product1.getPercentile());
assertThat(3).isEqualTo(product1.getBidder_ranking());
}

@Test
void findLB() 
{
LeaderBoard lb=new LeaderBoard(10,8, 2, 80.9,3);
 leaderboardDAOImpl.save(lb);
LeaderBoard product1 = leaderboardDAOImpl.find(lb.getBidderId());
assertThat(product1.getBidsParticipated()).isGreaterThan(0);
assertThat(product1.getBidsWon()).isGreaterThan(0);
assertThat(product1.getBidLost()).isGreaterThan(0);
assertThat(product1.getPercentile()).isGreaterThan(0);
assertThat(product1.getBidder_ranking()).isGreaterThan(0);
}

@Test
void updateLB() {
LeaderBoard lb=new LeaderBoard(10,8, 2, 80.9,3);
lb.setBidsParticipated(5);
lb.setBidsWon(3);
lb.setBidLost(2);
lb.setPercentile(50.0);
lb.setBidder_ranking(5);
leaderboardDAOImpl.save(lb);
LeaderBoard product1 = leaderboardDAOImpl.find(lb.getBidderId());
assertThat(product1.getBidsParticipated()).isEqualTo(5);
assertThat(product1.getBidsWon()).isEqualTo(3);
assertThat(product1.getBidLost()).isEqualTo(2);
assertThat(product1.getPercentile()).isEqualTo(50.0);
assertThat(product1.getBidder_ranking()).isEqualTo(5);
 }
 
@Test
void deleteLB() {
LeaderBoard lb=new LeaderBoard(5,3, 2, 50.0,5);
leaderboardDAOImpl.delete(lb);
LeaderBoard product1 = leaderboardDAOImpl.find(lb.getBidderId());
assertThat(product1).isNull();
}
 
 @Test
void saveResult() {
Result result=new Result("CSK","RCB","MI");
resultDAOImpl.save(result);
 Result product1 = resultDAOImpl.find(result.getId());
assertThat("CSK").isEqualTo(product1.getFirstTeam());
assertThat("RCB").isEqualTo(product1.getSecondTeam());
assertThat("MI").isEqualTo(product1.getThirdTeam());
}
@Test
void findR() 
{
Result result=new Result("CSK","RCB","MI");
resultDAOImpl.save(result);
Result product1 = resultDAOImpl.find(result.getId());

assertThat(product1.getFirstTeam()).hasSizeGreaterThan(0);
assertThat(product1.getSecondTeam()).hasSizeGreaterThan(0);
assertThat(product1.getThirdTeam()).hasSizeGreaterThan(0);
}

@Test
void updateR()
{
Result result=new Result("CSK","RCB","MI");
result.setFirstTeam("DC");
result.setSecondTeam("pbks");
result.setThirdTeam("RR");
resultDAOImpl.save(result);
Result product1 = resultDAOImpl.find(result.getId());

assertThat(product1.getFirstTeam()).isEqualTo("DC");
assertThat(product1.getSecondTeam()).isEqualTo("pbks");
assertThat(product1.getThirdTeam()).isEqualTo("RR");
}

@Test
void deleteR() {
Result result=new Result("DC","pbks","RR");
resultDAOImpl.delete(result);
Result result1 = resultDAOImpl.find(result.getId());
assertThat(result1).isNull();
}

@Test
void saveTournament() {
Tournaments t=new Tournaments(8,date);
tournamentDAOImpl.save(t);
 Tournaments t1 = tournamentDAOImpl.findTournaments(t.getTournamentId());
assertThat(8).isEqualTo(t1.getNumberOfTeams());
assertThat(date).isEqualTo(t1.getDuration());
}

@Test
void findTournament() 
{
Tournaments t=new Tournaments(8,date);
tournamentDAOImpl.save(t);
Tournaments t1 = tournamentDAOImpl.findTournaments(t.getTournamentId());

assertThat(t1.getNumberOfTeams()).isGreaterThan(0);
}

@Test
void updateTournament() {
Tournaments t=new Tournaments(8,date);
t.setNumberOfTeams(9);
tournamentDAOImpl.save(t);
Tournaments t1 = tournamentDAOImpl.findTournaments(t.getTournamentId());
assertThat(t1.getNumberOfTeams()).isEqualTo(9);
}

@Test
void saveTeam() {
Team team=new Team("RCB",14,13,"100");
teamDAOImpl.save(team);
Team profile1 = teamDAOImpl.findTeam(team.getTeamId());
assertThat("RCB").isEqualTo(profile1.gettName());
assertThat(14).isEqualTo(profile1.getPoints());
assertThat(13).isEqualTo(profile1.getRanking());
assertThat("100").isEqualTo(profile1.getStatistics());
}

@Test
void findTeam() {
Team team=new Team("RCB",14,3,"100");
teamDAOImpl.save(team);
Team profile1 = teamDAOImpl.findTeam(team.getTeamId());
assertThat(profile1.gettName()).hasSizeGreaterThan(0);
assertThat(profile1.getPoints()).isGreaterThan(0);
assertThat(profile1.getRanking()).isGreaterThan(0);
assertThat(profile1.getStatistics()).hasSizeGreaterThan(0);
}

@Test
void updateTeam() {
Team product=new Team("RCB",14,3,"100");
product.settName("CSK");
product.setPoints(18);
product.setRanking(1);
product.setStatistics("103");
teamDAOImpl.save(product);
Team profile1 = teamDAOImpl.findTeam(product.getTeamId());
assertThat("CSK").isEqualTo(profile1.gettName());
assertThat(18).isEqualTo(profile1.getPoints());
assertThat(1).isEqualTo(profile1.getRanking());
assertThat("103").isEqualTo(profile1.getStatistics());
}

@Test
void deleteTeam() {
Team team=new Team("RCB",14,3,"100");
teamDAOImpl.delete(team);
Team profile1 = teamDAOImpl.findTeam(team.getTeamId());
assertThat(profile1).isNull();
}

@Test
void contextLoads30() {
Admin admin=new Admin("ashu", "apple");
adminDAOImpl.login(admin);
Admin admin1=adminDAOImpl.findadmin(admin.getAdminId());
assertThat("ashu").isEqualTo(admin1.getUserName());
	}


@Test
void contextLoads31() {
Tournaments t=new Tournaments(8,date);
adminDAOImpl.manageTournoment(t);
Tournaments t1 = tournamentDAOImpl.findTournaments(t.getTournamentId());
assertThat(8).isEqualTo(t1.getNumberOfTeams());
	}

@Test
void contextLoads32() {
Match match=new Match("RCB","CSK",date,"Sharjah","CSK");
adminDAOImpl.scheduleMatches(match);
Match product1 = matchDAOImpl.find(match.getMatchId());
assertThat(date).isEqualTo(product1.getDate());
	}


@Test
void cancelMatch() {
Match match=new Match("RCB","CSK",date,"Sharjah","CSK");
matchDAOImpl.cancelMatch(match);
Match product1 = matchDAOImpl.find(match.getMatchId());
assertThat(product1).isNull();
}


}

